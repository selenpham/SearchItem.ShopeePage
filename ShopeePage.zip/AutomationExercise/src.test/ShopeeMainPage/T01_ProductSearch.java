package ShopeeMainPage;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.Hooks;
import pageObjects.ShopMainPage;


@Listeners(resources.Listeners.class)
public class T01_ProductSearch extends Hooks{

	public T01_ProductSearch() throws IOException {
		super();
	}
	
	@Test
	public void tc01_searchItem() throws IOException, InterruptedException {
	    ShopMainPage prodPage = new ShopMainPage();
	    Thread.sleep(2000);

// Scroll back to main page to avoid interacting with iframe.
	    getDriver().switchTo().parentFrame();
		int sizeIFrame = getDriver().findElements(By.tagName("iframe")).size();
		System.out.println("number of iframe: "+sizeIFrame);

// Interact with elements on the main page.
	   

	    Actions act = new Actions(getDriver());
	    act.doubleClick().build().perform();
	    Thread.sleep(2000);


//fill keyword and search
	    prodPage.fillInputSearch().sendKeys("váy chữ A");
	    Thread.sleep(2000);
	    prodPage.clickSearchIcon().click();
	    Thread.sleep(2000);

	}
		
	   
}
