package ShopeeMainPage;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.Hooks;
import pageObjects.ShopMainPage;

@Listeners(resources.Listeners.class)
public class T01_ProductSearch_1 extends Hooks{

	public T01_ProductSearch_1() throws IOException {
		super();
	}
	
	@Test
	public void tc01_searchItem() throws IOException, InterruptedException {
	    ShopMainPage prodPage = new ShopMainPage();
	    prodPage.clickTroVe().click();
		
		Thread.sleep(2000);

//fill keyword and search
	    prodPage.fillInputSearch().sendKeys("shampo");
	    Thread.sleep(2000);
	    prodPage.clickSearchIcon().click();
	    Thread.sleep(2000);

	}
		
	   
}
