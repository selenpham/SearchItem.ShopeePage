package pageObjects;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import base.BasePage;

public class ShopMainPage<Actions> extends BasePage{


	public WebDriver driver;
	
	By closePopPoint = By.xpath("//*[@id='main']/div/div[2]/div/shopee-banner-popup-stateful//div/div/div/div/div");
	By inputSearch = By.xpath("//*[@id='main']/div/header/div[2]/div/div[1]/div[1]/div/form/input");
	By searchIcon = By.cssSelector(".shopee-searchbar__search-button");
	By trove = By.xpath("/html/body/main/div[2]/div/a");
	
	
	public ShopMainPage() throws IOException {
		super();
	}
	
	public WebElement clickClosePop() throws IOException {
		this.driver = getDriver();
		return driver.findElement(closePopPoint);
	}
	
	public WebElement fillInputSearch() throws IOException {
		this.driver = getDriver();
		return driver.findElement(inputSearch);
	}
	
	public WebElement clickSearchIcon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(searchIcon);
	}
	
	public WebElement clickTroVe() throws IOException {
		this.driver = getDriver();
		return driver.findElement(trove);
	}
		
	
}
